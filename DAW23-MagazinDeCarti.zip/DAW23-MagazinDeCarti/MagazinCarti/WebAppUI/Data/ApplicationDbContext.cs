﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using WebAppUI.Models.CustomIdentity;
using WebAppUI.Models.Entities;
using WebAppUI.Areas.Admin.Models.DTOs;
using WebAppUI.Models.ViewModels;

namespace WebAppUI.Data
{
    public class ApplicationDbContext : IdentityDbContext<AppUser, AppRole, int>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Autor> Autori { get; set; }
        public DbSet<Editura> Edituri { get; set; }
        public DbSet<Moneda> Monezi { get; set; }
        public DbSet<Carte> Carti { get; set; }
        public DbSet<CarteAutor> CarteAutori { get; set; }
        public DbSet<CarteOferta> Oferte { get; set; }
        public DbSet<EdituraManager> EdituraManageri { get; set; }
        public DbSet<WebAppUI.Models.ViewModels.CardAutorVm> CardAutorVm { get; set; } = default!;

        //protected override void OnModelCreating(ModelBuilder modelBuilding)
        //{
        //    modelBuilding.Entity<EdituraManager>()
        //        .HasKey(pk => new { pk.EdituraId, pk.ManagerId });

        //}
    }
}
