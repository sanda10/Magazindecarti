﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebAppUI.Areas.Manager.Models.DTOs;
using WebAppUI.Areas.Manager.Models.ViewModels;
using WebAppUI.Data;
using WebAppUI.Models.Entities;

namespace WebAppUI.Areas.Manager.Controllers
{
    [Area("Manager")]
    [Authorize(Roles = "Manager")]
    public class OfertaController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;

        public OfertaController(ApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        // GET: Manager/Oferta
        [Route("Manager/Oferte")]
        public async Task<IActionResult> Index()
        {
            var EdituraCurenta = await _context.EdituraManageri
                        .Include(t => t.Manager)
                        .Where(q => q.Manager!.UserName == User!.Identity!.Name).FirstOrDefaultAsync();
            if (EdituraCurenta == null)
                return RedirectToRoute("/Manager");
            var oferte = _context.Oferte
                .Include(t => t.Carte)
                .ThenInclude(t => t!.Moneda)
                .Where(c => c.Carte!.EdituraId == EdituraCurenta.EdituraId);
            return View(_mapper.Map<List<OfertaCarteVm>>(await oferte.ToListAsync()));
        }

        // GET: Manager/Oferta/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Oferte == null)
            {
                return NotFound();
            }
            var EdituraCurenta = await _context.EdituraManageri
                        .Include(t => t.Manager)
                        .Where(q => q.Manager!.UserName == User!.Identity!.Name).FirstOrDefaultAsync();
            if (EdituraCurenta is null)
                return BadRequest();

            var OfertaExistenta = await _context.Oferte
                .Include(t => t.Carte)
                .ThenInclude(t => t!.Moneda)
                .FirstOrDefaultAsync(q => q.Id == id && q.Carte!.EdituraId == EdituraCurenta.EdituraId);
            if (OfertaExistenta == null)
            {
                return NotFound();
            }

            return View(_mapper.Map<OfertaCarteDto>(OfertaExistenta));
        }

        // GET: Manager/Oferta/Create
        public IActionResult Create()
        {
            ViewData["Id"] = new SelectList(_context.Carti, "Id", "Id");
            return View();
        }

        // POST: Manager/Oferta/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,TextPromo,PretNou")] CarteOferta carteOferta)
        {
            if (ModelState.IsValid)
            {
                _context.Add(carteOferta);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["Id"] = new SelectList(_context.Carti, "Id", "Id", carteOferta.Id);
            return View(carteOferta);
        }

        // GET: Manager/Oferta/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Oferte == null)
            {
                return NotFound();
            }

            var carteOferta = await _context.Oferte.FindAsync(id);
            if (carteOferta == null)
            {
                return NotFound();
            }
            ViewData["Id"] = new SelectList(_context.Carti, "Id", "Id", carteOferta.Id);
            return View(carteOferta);
        }

        // POST: Manager/Oferta/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,TextPromo,PretNou")] CarteOferta carteOferta)
        {
            if (id != carteOferta.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(carteOferta);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarteOfertaExists(carteOferta.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["Id"] = new SelectList(_context.Carti, "Id", "Id", carteOferta.Id);
            return View(carteOferta);
        }

        // GET: Manager/Oferta/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Oferte == null)
            {
                return NotFound();
            }

            var carteOferta = await _context.Oferte
                .Include(c => c.Carte)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (carteOferta == null)
            {
                return NotFound();
            }

            return View(carteOferta);
        }

        // POST: Manager/Oferta/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Oferte == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Oferte'  is null.");
            }
            var carteOferta = await _context.Oferte.FindAsync(id);
            if (carteOferta != null)
            {
                _context.Oferte.Remove(carteOferta);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CarteOfertaExists(int id)
        {
            return (_context.Oferte?.Any(e => e.Id == id)).GetValueOrDefault();
        }

        public async Task<ActionResult> GetOffer([FromRoute] int id)
        {
            var carte = await _context.Carti
                .Include(c => c.Editura)
                .Include(c => c.Moneda)
                .FirstOrDefaultAsync(m => m.Id == id && m.EsteFinala);
            if (carte == null)
            {
                return Json(new { success = false, errors = new string[] { "Cartea nu există!" } });
            }
            var ListaAutori = await _context.CarteAutori
                .Include(t => t.Autor).Where(c => c.CarteId == id)
                .OrderBy(o => o.Autor!.Nume)
                .ThenBy(o => o.Autor!.Prenume)
                .ToListAsync();

            var output = _mapper.Map<OfertaCarteDto>(carte);
            var autori = "";
            foreach (var autor in ListaAutori)
            {
                autori += $"{autor.Autor!.Nume} {autor.Autor!.Prenume}, ";
            }
            output.Autori = string.IsNullOrEmpty(autori) ? "-" : autori.Substring(0, autori.Length - 2);
            var Oferta = await _context.Oferte.FindAsync(id);
            if (Oferta is not null)
            {
                output.TextPromo = Oferta.TextPromo;
                output.PretNou = Oferta.PretNou;
                output.EsteOfertaNoua = false;
            }
            if (Oferta is null)
            {
                //return Json(new { success = false, errors = new string[] { "Oferta nu există!" } });
            }
            return Json(new { success = true, item = output });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> UpdateOffer([FromRoute] int id, [FromForm] AddEditOfertaCarteDto OfertaIntrodusa)
        {
            var OfertaExistenta = await _context.Oferte.FindAsync(id);
            var CarteExistenta = await _context.Carti
                .Include(t=>t.Moneda)
                .FirstOrDefaultAsync(i => i.Id == id && i.EsteFinala);
            if (CarteExistenta is null)
            {
                return Json(new { success = false, errors = new string[] { "Cartea nu există!" } });
            }

            if (OfertaIntrodusa.Id != CarteExistenta.Id)
            {
                return Json(new { success = false, errors = new string[] { "Bad Request!" } });
            }
            if (ModelState.IsValid)
            {
                if (OfertaIntrodusa.PretNou >= CarteExistenta.Pret)
                {
                    return Json(new { success = false, priceError = true, item=_mapper.Map<CartePretVm>(CarteExistenta), errors = new string[] { "Prețul nou trebuie să fie mai mic decât prețul vechi!" } });
                }
                if (OfertaExistenta is null)
                {
                    // inserăm oferta nouă
                    var OfertaNoua = _mapper.Map<CarteOferta>(OfertaIntrodusa);
                    Console.WriteLine($"Oferta nouă: {OfertaIntrodusa}, {OfertaNoua}");

                    //OfertaNoua.Id = id;
                    await _context.AddAsync(OfertaNoua);
                }
                else
                {
                    // modificăm oferta existentă
                    OfertaExistenta.TextPromo = OfertaIntrodusa.TextPromo;
                    OfertaExistenta.PretNou = OfertaIntrodusa.PretNou;
                    _context.Update(OfertaExistenta);
                }
                await _context.SaveChangesAsync();
                return Json(new { success = true, item = OfertaIntrodusa });
            }
            var errors = ModelState.SelectMany(x => x.Value!.Errors.Select(e => e.ErrorMessage));
            return Json(new { success = false, errors });
        }

        [HttpDelete]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteOffer([FromRoute] int id, int CarteId)
        {
            var OfertaExistenta = await _context.Oferte.FindAsync(id);
            if (OfertaExistenta is null)
            {
                return Json(new { success = false, errors = new string[] { "Oferta nu există!" } });
            }
            if (id != CarteId)
            {
                return Json(new { success = false, errors = new string[] { "Bad Request!" } });
            }
            _context.Oferte.Remove(OfertaExistenta);
            await _context.SaveChangesAsync();
            return Json(new { success = true, item = OfertaExistenta });
        }
    }
}
