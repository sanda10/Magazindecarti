﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebAppUI.Areas.Manager.Models.DTOs;
using WebAppUI.Areas.Manager.Models.ViewModels;
using WebAppUI.Models.Entities;
namespace WebAppUI.Areas.Manager.Controllers;

[Area("Manager")]
[Authorize]
public class AutorController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly IMapper _mapper;

    public AutorController(ApplicationDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    // GET: Manager/Autor
    [Route("Manager/Autori")]
    public async Task<IActionResult> Index()
    {
        if (_context.Autori == null)
            return Problem("Entity set 'ApplicationDbContext.Autori'  is null.");
        var autori = await _context.Autori.ToListAsync();
        //List<AutorScurtVm> lista = new();
        //foreach(var autor in autori)
        //{
        //    lista.Add(new AutorScurtVm(autor.Id, autor.Prenume, autor.Nume));
        //}
        //return View(lista);
        return  View(_mapper.Map<List<AutorScurtVm>>(autori));
    }

    // GET: Manager/Autor/Details/5
    public async Task<IActionResult> Details(int? id)
    {
        if (id == null || _context.Autori == null)
        {
            return NotFound();
        }

        var autor = await _context.Autori
            .FirstOrDefaultAsync(m => m.Id == id);
        if (autor == null)
        {
            return NotFound();
        }

        return View(_mapper.Map<AutorDetaliiVm>(autor));
    }

    // GET: Manager/Autor/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST: Manager/Autor/Create
    // To protect from overposting attacks, enable the specific properties you want to bind to.
    // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([FromForm]AutorNouDto AutorNou)
    {
        if (ModelState.IsValid)
        {
            //Autor autor = new()
            //{
            //    Prenume = autorNou.Prenume,
            //    Nume = autorNou.Nume,
            //    DataNastere = autorNou.DataNastere
            //};
            //_context.Add(autor);
            var Autor = _mapper.Map<Autor>(AutorNou);
            _context.Add(Autor);
            await _context.SaveChangesAsync();
            TempData["MesajAutor"] = $"Autorul <strong>{AutorNou.Prenume} {AutorNou.Nume}</strong> a fost adăugat cu succes!";
            return RedirectToAction(nameof(Index));
        }
        return View(AutorNou);
    }

    // GET: Manager/Autor/Edit/5
    public async Task<IActionResult> Edit(int id)
    {
        if (_context.Autori == null)
        {
            return NotFound();
        }

        var autorExistent = _mapper.Map<AutorExistentDto>(await _context.Autori.FindAsync(id));
        if (autorExistent == null)
        {
            return NotFound();
        }
        return View(autorExistent);
    }

    // POST: Manager/Autor/Edit/5
    // To protect from overposting attacks, enable the specific properties you want to bind to.
    // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [FromForm]AutorExistentDto autorExistent)
    {
        var autor = await _context.Autori.FindAsync(id);
        if (id != autorExistent.AutorId || id!=autor!.Id)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            try
            {
                TempData["MesajAutor"] = $"Autorul <strong>{autor.Prenume} {autor.Nume}</strong> a fost actualizat în <strong>{autorExistent.Prenume} {autorExistent.Nume}</strong> cu succes!";
                autorExistent.ToEntity(ref autor);
                _context.Update(autor);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AutorExists(autorExistent.AutorId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return RedirectToAction(nameof(Index));
        }
        return View(autorExistent);
    }

    // GET: Manager/Autor/Delete/5
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null || _context.Autori == null)
        {
            return NotFound();
        }

        var autor = await _context.Autori
            .FirstOrDefaultAsync(m => m.Id == id);
        if (autor == null)
        {
            return NotFound();
        }

        return View(_mapper.Map<AutorScurtVm>(autor));
    }

    // POST: Manager/Autor/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        if (_context.Autori == null)
        {
            return Problem("Entity set 'ApplicationDbContext.Autori'  is null.");
        }
        var AutorExistent = await _context.Autori.FindAsync(id);
        if (AutorExistent is null)
            return NotFound();
        var AutorInCarti = await _context.CarteAutori.Where(q=>q.AutorId == id).CountAsync();
        if (AutorInCarti==0)
        {
            _context.Autori.Remove(AutorExistent);
            TempData["MesajAutor"] = $"Autorul <strong>{AutorExistent.Prenume} {AutorExistent.Nume}</strong> a fost șters cu succes!";
            await _context.SaveChangesAsync();
        }
        else
        {
            TempData["MesajAutor"] = $"<strong>{AutorExistent.Prenume} {AutorExistent.Nume}</strong> NU a fost șters pentru că este autor în {AutorInCarti} cărți!";
        }
        return RedirectToAction(nameof(Index));
    }

    // GET: Manager/Autor/Edit/5
    public async Task<IActionResult> AddBook(int id)
    {
        if (_context.Autori == null)
        {
            return NotFound();
        }

        var AutorExistent = _mapper.Map<AutorAdaugaCarteDto>(await _context.Autori.FindAsync(id));
        if (AutorExistent == null)
        {
            return NotFound();
        }
        var EdituraCurenta = await _context.EdituraManageri
                .Include(t => t.Editura)
                .Include(t => t.Manager)
                .FirstOrDefaultAsync(q => q.Manager!.UserName == User.Identity!.Name);
        if (EdituraCurenta == null)
            return NotFound();//redirectionez
        var carti = _mapper.Map<List<CarteDto>>(
            await _context.Carti
                .Include(t => t.Autori)
                .Where(q => q.EdituraId == EdituraCurenta.EdituraId && !q.EsteFinala).ToListAsync());
        ViewBag.AvailableBooks = new SelectList(carti, "CarteId", "Titlu");
        return View(AutorExistent);
    }

    // POST: Manager/Autor/Edit/5
    // To protect from overposting attacks, enable the specific properties you want to bind to.
    // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AddBook(int id, [FromForm] AutorAdaugaCarteDto AutorAdaugaCarte)
    {
        var AutorExistent = await _context.Autori.FindAsync(id);
        var CarteExistenta = await _context.Carti.FindAsync(AutorAdaugaCarte.CarteId);
        if(AutorExistent is null || CarteExistenta is null)
            return NotFound();
        if (id != AutorAdaugaCarte.AutorId || id != AutorExistent!.Id)
        {
            return BadRequest();
        }

        if (ModelState.IsValid)
        {
            try
            {
                var AutorExistentCarte = await _context.CarteAutori.FirstOrDefaultAsync(q => q.AutorId == AutorAdaugaCarte.AutorId && q.CarteId == AutorAdaugaCarte.CarteId);
                if(AutorExistentCarte is null)
                {
                    CarteAutor CarteAutor = new()
                    {
                        AutorId = AutorAdaugaCarte.AutorId,
                        CarteId = AutorAdaugaCarte.CarteId
                    };
                    await _context.CarteAutori.AddAsync(CarteAutor);
                    await _context.SaveChangesAsync();
                    TempData["MesajAutor"] = $"Autorul <strong>{AutorExistent.Prenume} {AutorExistent.Nume}</strong> a fost asociat cu succes cărții {CarteExistenta.Titlu}!";
                }
                else
                {
                    TempData["MesajAutor"] = $"Autorul <strong>{AutorExistent.Prenume} {AutorExistent.Nume}</strong> este DEJA asociat cărții {CarteExistenta.Titlu}!";
                }
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CarteAutorExists(AutorAdaugaCarte.AutorId, AutorAdaugaCarte.CarteId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return RedirectToAction(nameof(Index));
        }
        return View(AutorAdaugaCarte);
    }

    private bool AutorExists(int AutorId)
    {
        return (_context.Autori?.Any(e => e.Id == AutorId)).GetValueOrDefault();
    }

    private bool CarteAutorExists(int AutorId, int CarteId)
    {
      return (_context.CarteAutori?.Any(e => e.AutorId == AutorId && e.CarteId == CarteId)).GetValueOrDefault();
    }
}
