﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using WebAppUI.Areas.Manager.Models.DTOs;
using WebAppUI.Areas.Manager.Models.ViewModels;
using WebAppUI.Data;
using WebAppUI.Models.CustomIdentity;
using WebAppUI.Models.Entities;

namespace WebAppUI.Areas.Manager.Controllers
{
    [Area("Manager")]
    [Authorize(Roles = "Manager")]
    public class CarteController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly UserManager<AppUser> _userManager;

        public CarteController(ApplicationDbContext context, IMapper mapper,
            UserManager<AppUser> userManager)
        {
            _context = context;
            _mapper = mapper;
            _userManager = userManager;
        }

        // GET: Manager/Carte
        [Route("Manager/Carti")]
        public async Task<IActionResult> Index()
        {
            var EdituraCurenta = await _context.EdituraManageri
                .Include(t => t.Editura)
                .Include(t => t.Manager)
                .FirstOrDefaultAsync(q => q.Manager!.UserName == User.Identity!.Name);
            if (EdituraCurenta == null)
                return NotFound();//redirectionez
            var carti = _mapper.Map<List<CarteVm>>(
                await _context.Carti
                    .Include(c => c.Moneda)
                    .Where(q => q.EdituraId == EdituraCurenta.EdituraId).ToListAsync());
            var output = new IndexCartiVm()
            {
                Editura = EdituraCurenta.Editura!.Denumire,
                ListaCarti = carti
            };
            return View(output);
        }

        // GET: Manager/Carte/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Carti == null)
            {
                return NotFound();
            }

            var carte = await _context.Carti
                .Include(c => c.Editura)
                .Include(c => c.Moneda)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (carte == null)
            {
                return NotFound();
            }
            var ListaAutori = await _context.CarteAutori
                .Include(t => t.Autor).Where(c => c.CarteId == id)
                .OrderBy(o => o.Autor!.Nume)
                .ThenBy(o => o.Autor!.Prenume)
                .ToListAsync();

            var output = _mapper.Map<CarteDetaliiVm>(carte);
            var autori = "";
            foreach (var autor in ListaAutori)
            {
                autori += $"{autor.Autor!.Nume} {autor.Autor!.Prenume}, ";
            }
            output.Autori = string.IsNullOrEmpty(autori) ? "-" : autori.Substring(0, autori.Length - 2);
            return View(output);
        }

        // GET: Manager/Carte/Create
        public IActionResult Create()
        {
            ViewData["MonedaId"] = new SelectList(_context.Monezi, "Id", "Acronim");
            return View();
        }

        // POST: Manager/Carte/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([FromForm] CarteNouaDto carteNoua)
        {
            var UtilizatorCurent = await _userManager.FindByEmailAsync(User.Identity!.Name!);
            var EdituraCurenta = await _context.EdituraManageri.Where(q => q.ManagerId == UtilizatorCurent!.Id).FirstOrDefaultAsync();
            if (EdituraCurenta == null)
                return BadRequest();
            if (ModelState.IsValid)
            {
                var CarteNoua = _mapper.Map<Carte>(carteNoua);
                CarteNoua.EdituraId = EdituraCurenta!.EdituraId;
                _context.Add(CarteNoua);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["MonedaId"] = new SelectList(_context.Monezi, "Id", "Acronim", carteNoua.MonedaId);
            return View(carteNoua);
        }

        // GET: Manager/Carte/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Carti == null)
            {
                return NotFound();
            }
            var EdituraCurenta = await _context.EdituraManageri
                .Include(t => t.Manager)
                .Where(q => q.Manager!.UserName == User!.Identity!.Name).FirstOrDefaultAsync();
            if (EdituraCurenta is null)
                return BadRequest();
            var carteExistenta = await _context.Carti
                .FirstOrDefaultAsync(q => q.Id == id && q.EdituraId == EdituraCurenta.EdituraId);
            if (carteExistenta == null)
            {
                return NotFound();
            }
            ViewData["MonedaId"] = new SelectList(_context.Monezi, "Id", "Acronim", carteExistenta.MonedaId);
            var autori = await _context.CarteAutori
                .Include(t => t.Autor).Where(c => c.CarteId == id)
                .OrderBy(o => o.Autor!.Nume)
                .ThenBy(o => o.Autor!.Prenume)
                .ToListAsync();
            var output = new CarteEditDto()
            {
                CarteExistenta = _mapper.Map<CarteExistentaDto>(carteExistenta),
                ListaAutori = _mapper.Map<List<AutorScurtVm>>(autori)
            };
            return View(output);
        }

        // POST: Manager/Carte/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit([FromRoute] int id, [FromForm] CarteEditDto CarteModificata)
        {
            if (CarteModificata.CarteExistenta is null || id != CarteModificata.CarteExistenta!.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var EdituraCurenta = await _context.EdituraManageri
                        .Include(t => t.Manager)
                        .Where(q => q.Manager!.UserName == User!.Identity!.Name).FirstOrDefaultAsync();
                    if (EdituraCurenta is null)
                        return BadRequest();
                    var CarteExistenta = await _context.Carti
                        .FirstOrDefaultAsync(q => q.Id == id && q.EdituraId == EdituraCurenta.EdituraId);
                    if (CarteExistenta == null)
                    {
                        return NotFound();
                    }
                    CarteModificata.CarteExistenta.ToEntity(ref CarteExistenta);
                    _context.Update(CarteExistenta);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarteExists(CarteModificata.CarteExistenta.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["MonedaId"] = new SelectList(_context.Monezi, "Id", "Id", CarteModificata.CarteExistenta.MonedaId);
            var autori = await _context.CarteAutori
                .Include(t => t.Autor).FirstOrDefaultAsync(c => c.CarteId == id);
            CarteModificata.ListaAutori = _mapper.Map<List<AutorScurtVm>>(autori);
            return View(CarteModificata);
        }

        // GET: Manager/Carte/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Carti == null)
            {
                return NotFound();
            }

            var carte = await _context.Carti
                .Include(c => c.Editura)
                .Include(c => c.Moneda)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (carte == null)
            {
                return NotFound();
            }
            var ListaAutori = await _context.CarteAutori
                .Include(t => t.Autor).Where(c => c.CarteId == id)
                .OrderBy(o => o.Autor!.Nume)
                .ThenBy(o => o.Autor!.Prenume)
                .ToListAsync();
            var output = _mapper.Map<CarteDetaliiVm>(carte);
            var autori = "";
            foreach (var autor in ListaAutori)
            {
                autori += $"{autor.Autor!.Nume} {autor.Autor!.Prenume}, ";
            }
            output.Autori = string.IsNullOrEmpty(autori) ? "-" : autori.Substring(0, autori.Length - 2);
            return View(output);
        }

        // POST: Manager/Carte/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Carti == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Carti'  is null.");
            }
            var carte = await _context.Carti.FindAsync(id);
            if (carte != null)
            {
                _context.Carti.Remove(carte);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Manager/Carte/Details/5
        public async Task<IActionResult> Offer(int? id)
        {
            if (id == null || _context.Carti == null)
            {
                return NotFound();
            }

            var carte = await _context.Carti
                .Include(c => c.Editura)
                .Include(c => c.Moneda)
                .FirstOrDefaultAsync(m => m.Id == id && m.EsteFinala);
            if (carte == null)
            {
                return RedirectToAction(nameof(Index));
            }
            var ListaAutori = await _context.CarteAutori
                .Include(t => t.Autor).Where(c => c.CarteId == id)
                .OrderBy(o => o.Autor!.Nume)
                .ThenBy(o => o.Autor!.Prenume)
                .ToListAsync();

            var output = _mapper.Map<OfertaCarteDto>(carte);
            var autori = "";
            foreach (var autor in ListaAutori)
            {
                autori += $"{autor.Autor!.Nume} {autor.Autor!.Prenume}, ";
            }
            output.Autori = string.IsNullOrEmpty(autori) ? "-" : autori.Substring(0, autori.Length - 2);
            var Oferta = await _context.Oferte.FindAsync(id);
            if (Oferta is not null)
            {
                output.TextPromo = Oferta.TextPromo;
                output.PretNou = Oferta.PretNou;
                output.EsteOfertaNoua = false;
            }
            return View(output);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Offer([FromRoute] int? id, [FromForm] OfertaCarteDto OfertaNoua)
        {
            if (id == null || _context.Carti == null)
            {
                return NotFound();
            }
            var EdituraCurenta = await _context.EdituraManageri
                        .Include(t => t.Manager)
                        .Where(q => q.Manager!.UserName == User!.Identity!.Name).FirstOrDefaultAsync();
            if (EdituraCurenta is null)
                return BadRequest();
            var CarteExistenta = await _context.Carti
                .Include(t => t.Moneda)
                .FirstOrDefaultAsync(m => m.Id == id && m.EsteFinala && m.EdituraId == EdituraCurenta.EdituraId);
            if (CarteExistenta == null)
            {
                return RedirectToAction(nameof(Index));
            }
            if (ModelState.IsValid)
            {
                var OfertaExistenta = await _context.Oferte
                    .Include(t => t.Carte)
                    .ThenInclude(t => t!.Moneda)
                    .FirstOrDefaultAsync(m => m.Id == id);

                if (OfertaExistenta is null)
                {
                    // adaugă oferta
                    var Oferta = _mapper.Map<CarteOferta>(OfertaNoua);
                    await _context.AddAsync(Oferta);
                }
                else
                {
                    // actualizează oferta
                    OfertaExistenta.PretNou = OfertaNoua.PretNou;
                    OfertaExistenta.TextPromo = OfertaNoua.TextPromo;
                    _context.Update(OfertaExistenta);
                }
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(OfertaNoua);
        }

        private bool CarteExists(int id)
        {
            return (_context.Carti?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
