﻿using System.ComponentModel.DataAnnotations;
namespace WebAppUI.Areas.Manager.Models.ViewModels;
public class AutorDetaliiVm
{
    public int Id { get; set; }
    [Display(Name = "Autor")]
    public string NumeComplet { get; set; }=string.Empty;
    [Display(Name ="Data Nașterii"),DisplayFormat(DataFormatString ="{0:d MMMM yyyy}")]
    public DateTime DataNastere { get; set; }
}
