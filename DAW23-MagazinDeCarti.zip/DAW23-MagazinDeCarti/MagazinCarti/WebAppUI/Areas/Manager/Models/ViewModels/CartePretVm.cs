public class CartePretVm{
    public int Id { get; set; }
    public decimal Pret { get; set; }
    public string Moneda { get; set; }=string.Empty;
}