﻿using System.ComponentModel.DataAnnotations;

namespace WebAppUI.Areas.Manager.Models.ViewModels;
public class OfertaCarteVm
{
    public int Id { get; set; }
    public required string Titlu { get; set; }
    [Display(Name ="Promo")]
    public required string TextPromo { get; set; }
    public decimal Pret { get; set; }
    [Display(Name ="Preț Nou")]
    public decimal PretNou { get; set; }
    public required string Moneda { get; set; }
}
