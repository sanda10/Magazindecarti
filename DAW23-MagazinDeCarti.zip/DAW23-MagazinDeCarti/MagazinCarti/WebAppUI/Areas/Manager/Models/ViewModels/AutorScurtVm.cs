﻿using System.ComponentModel.DataAnnotations;
namespace WebAppUI.Areas.Manager.Models.ViewModels;
public class AutorScurtVm
{
    public int AutorId { get; set; }
    [Display(Name = "Autori")]
    public string NumeComplet { get; set; }=string.Empty;
    //public AutorScurtVm(int id, string firstname, string lastname)
    //{
    //    Id = id;
    //    NumeComplet = $"{lastname} {firstname}" ;
    //}
}
