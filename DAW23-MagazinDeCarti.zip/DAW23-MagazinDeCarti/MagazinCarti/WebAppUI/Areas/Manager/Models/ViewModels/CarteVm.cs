﻿using System.ComponentModel.DataAnnotations;
using WebAppUI.Validators;

namespace WebAppUI.Areas.Manager.Models.ViewModels;
public class CarteVm
{
    public int Id { get; set; }
    public string Titlu { get; set; } = string.Empty;
    public string ISBN { get; set; }=string.Empty;
    [Display(Name ="Publicare")]
    public short AnPublicare { get; set; }
    [Display(Name ="Preț")]
    public decimal Pret { get; set; }
    public string Moneda { get; set; }=string.Empty;
    [Display(Name = "Finală?")]
    public bool EsteFinala { get; set; }
    public List<AutorScurtVm>? ListaAutori { get; set; }

}
