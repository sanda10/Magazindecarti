﻿namespace WebAppUI.Areas.Manager.Models.ViewModels
{
    public class IndexCartiVm
    {
        public required string Editura { get; set; }
        public List<CarteVm>? ListaCarti { get; set; }
    }
}
