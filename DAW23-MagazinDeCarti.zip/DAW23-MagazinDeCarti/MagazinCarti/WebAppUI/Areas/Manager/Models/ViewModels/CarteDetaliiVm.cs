﻿using System.ComponentModel.DataAnnotations;
namespace WebAppUI.Areas.Manager.Models.ViewModels;
public class CarteDetaliiVm
{
    public int Id { get; set; }
    public string Titlu { get; set; } = string.Empty;
    public string ISBN { get; set; } = string.Empty;
    [Display(Name = "Publicare")]
    public short AnPublicare { get; set; }
    [Display(Name = "Preț")]
    public decimal Pret { get; set; }
    public string Moneda { get; set; } = string.Empty;
    [Display(Name = "Finală?")]
    public bool EsteFinala { get; set; }
    public required string Autori { get; set; }
}
