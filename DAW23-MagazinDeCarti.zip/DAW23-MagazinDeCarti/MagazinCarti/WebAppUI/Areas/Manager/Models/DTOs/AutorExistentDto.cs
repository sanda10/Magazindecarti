﻿using System.ComponentModel.DataAnnotations;
using WebAppUI.Validators;
namespace WebAppUI.Areas.Manager.Models.DTOs;
public class AutorExistentDto
{
    public int AutorId { get; set; }
    [MaxLength(50),Required]
    public string Prenume { get; set; } = string.Empty;
    [MaxLength(50),Required]
    public string Nume { get; set; } = string.Empty;
    [Required,DataNastere,Display(Name ="Data Nașterii:"),DataType(DataType.Date), DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:yyyy-MM-dd}")]
    public DateTime DataNastere { get; set; }

    public void ToEntity(ref Autor AutorExistent)
    {
        if(AutorExistent.Id == AutorId)
        {
            AutorExistent.Prenume = Prenume;
            AutorExistent.Nume = Nume;
            AutorExistent.DataNastere = DataNastere;
        }
    }
}
