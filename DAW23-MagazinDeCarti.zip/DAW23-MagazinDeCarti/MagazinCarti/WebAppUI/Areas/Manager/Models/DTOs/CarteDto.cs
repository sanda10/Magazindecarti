﻿using System.ComponentModel.DataAnnotations;

namespace WebAppUI.Areas.Manager.Models.DTOs;
public class CarteDto
{
    public int CarteId { get; set; }
    public required string Titlu { get; set; }
}
