﻿using System.ComponentModel.DataAnnotations;
using WebAppUI.Validators;

namespace WebAppUI.Areas.Manager.Models.DTOs;
public class CarteNouaDto
{
    [Required, MaxLength(400)]
    public required string Titlu { get; set; }
    [Required,MaxLength(13),ISBN]
    public required string ISBN { get; set; }
    [Required]
    [Display(Name ="Publicare")]
    public int AnPublicare { get; set; }
    [DisplayFormat(DataFormatString ="{0:###0.00}")]
    [Display(Name ="Preț"),Pret]
    public decimal Pret { get; set; }
    [Display(Name ="Moneda")]
    public int MonedaId { get; set; }
}
