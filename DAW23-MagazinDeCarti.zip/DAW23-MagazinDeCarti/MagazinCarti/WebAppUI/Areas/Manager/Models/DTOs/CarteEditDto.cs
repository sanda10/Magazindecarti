﻿using WebAppUI.Areas.Manager.Models.ViewModels;

namespace WebAppUI.Areas.Manager.Models.DTOs;
public class CarteEditDto
{
    public CarteExistentaDto? CarteExistenta { get; set; }
    public List<AutorScurtVm>? ListaAutori { get; set; }
}
