﻿using System.ComponentModel.DataAnnotations;
using WebAppUI.Validators;
namespace WebAppUI.Areas.Manager.Models.DTOs;
public class OfertaCarteDto
{
    public int Id { get; set; }
    public required string Titlu { get; set; }
    public required string Autori { get; set; }
    [Required, Display(Name ="Text Promo")]
    public required string TextPromo { get; set; }
    [Display(Name = "Preț vechi"),Pret]
    public decimal Pret { get; set; }
    [Required, Display(Name ="Preț Nou"), PretMaiMicDecat("Pret"), Pret]
    public decimal PretNou { get; set; }
    public required string Moneda { get; set; }
    public bool EsteOfertaNoua { get; set; } = true;
}
