﻿using System.ComponentModel.DataAnnotations;
using WebAppUI.Validators;
namespace WebAppUI.Areas.Manager.Models.DTOs;
public class AutorNouDto
{
    [MaxLength(50,ErrorMessage ="{0} trebuie să fie de maxim {1} caractere!")]
    public string Prenume { get; set; } = string.Empty;
    public string Nume { get; set; } = string.Empty;
    [Display(Name ="Data Nașterii"),DataNastere,DataType(DataType.Date),DisplayFormat(ApplyFormatInEditMode =true, DataFormatString ="{0:yyyy-MM-dd}")]
    public DateTime DataNastere { get; set; }
}
