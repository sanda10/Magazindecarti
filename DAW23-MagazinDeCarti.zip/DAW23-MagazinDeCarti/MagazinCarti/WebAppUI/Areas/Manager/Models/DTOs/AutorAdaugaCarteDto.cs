﻿using System.ComponentModel.DataAnnotations;
using WebAppUI.Areas.Manager.Models.ViewModels;
namespace WebAppUI.Areas.Manager.Models.DTOs;
public class AutorAdaugaCarteDto
{
    public int AutorId { get; set; }
    public string Autor { get; set; } = string.Empty;
    [Display(Name ="Alege o Carte:")]
    public int CarteId { get; set; }
}
