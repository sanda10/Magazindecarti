﻿using WebAppUI.Areas.Admin.Models.DTOs;

namespace WebAppUI.Areas.Admin.Models.ViewModels;

public class EdituraManageriVm
{
    public int Id { get; set; }
    public string Denumire { get; set; } = string.Empty;
    public List<UtilizatorExistentDto>? listaManageri { get; set; }
}
