﻿using System.ComponentModel.DataAnnotations;
namespace WebAppUI.Areas.Admin.Models.DTOs;

public class EdituraManagerDto
{
    [Key]
    public int EdituraId { get; set; }
    public string Editura { get; set; } = string.Empty;
    [Display(Name ="Manager")]
    public int ManagerId { get; set; }
}
