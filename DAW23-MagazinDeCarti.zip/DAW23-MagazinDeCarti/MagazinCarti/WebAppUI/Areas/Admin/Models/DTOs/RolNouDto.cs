﻿using System.ComponentModel.DataAnnotations;
namespace WebAppUI.Areas.Admin.Models.DTOs;
public class RolNouDto
{
    [Key]
    public string Denumire { get; set; } = string.Empty;
}
