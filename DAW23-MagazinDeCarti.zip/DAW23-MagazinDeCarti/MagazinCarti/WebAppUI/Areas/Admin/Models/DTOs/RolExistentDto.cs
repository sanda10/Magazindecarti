﻿namespace WebAppUI.Areas.Admin.Models.DTOs;

public class RolExistent
{
    public int Id { get; set; }
    public string Denumire { get; set; } = string.Empty;
}
