﻿using System.ComponentModel.DataAnnotations;
namespace WebAppUI.Areas.Admin.Models.DTOs;
public class MonedaExistentaDto
{
    public int Id { get; set; }
    [Required,MaxLength(50)]
    public string Denumire { get; set; } = string.Empty;
    [Required,MaxLength(3)]
    public string Acronim { get; set; } = string.Empty;
}
