﻿using System.ComponentModel.DataAnnotations;

namespace WebAppUI.Areas.Admin.Models.DTOs;
public class UtilizatorExistentDto
{
    public int Id { get; set; }
    public string Email { get; set; } = string.Empty;
    [Display(Name ="Manager?")]
    public bool IsManager { get; set; } = false;
    [Display(Name ="Admin?")]
    public bool IsAdmin { get; set; } = false;
}
