﻿using System.ComponentModel.DataAnnotations;

namespace WebAppUI.Areas.Admin.Models.DTOs;

public class EdituraExistentaDto
{
    public int Id { get; set; }
    [MaxLength(50)]
    public string Denumire { get; set; } = string.Empty;
    public List<ManagerExistentDto>? Manageri { get; set; }
}
