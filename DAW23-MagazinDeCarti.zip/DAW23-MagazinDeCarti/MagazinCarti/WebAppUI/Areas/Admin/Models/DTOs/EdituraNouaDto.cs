﻿using System.ComponentModel.DataAnnotations;

namespace WebAppUI.Areas.Admin.Models.DTOs;
public class EdituraNouaDto
{
    [MaxLength(50)]
    public string Denumire { get; set; }=string.Empty;
}
