﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebAppUI.Areas.Admin.Models.DTOs;
using WebAppUI.Data;
using WebAppUI.Models.Entities;

namespace WebAppUI.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Administrator")]
    public class MonedaController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;

        public MonedaController(ApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        // GET: Admin/Moneda
        public async Task<IActionResult> Index()
        {
            //ViewData["Title"] = "Lista monezilor";
            //ViewBag.Titlu = "Lista monezilor";
            //TempData["Titlu"] = "Pagina unei monede";
            if(_context.Monezi == null)
                return Problem("Entity set 'ApplicationDbContext.Monezi'  is null.");
            return View(_mapper.Map<List<MonedaExistentaDto>>(await _context.Monezi.ToListAsync()));
        }

        // GET: Admin/Moneda/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Monezi == null)
            {
                return NotFound();
            }

            var moneda = await _context.Monezi
                .FirstOrDefaultAsync(m => m.Id == id);
            if (moneda == null)
            {
                return NotFound();
            }

            return View(_mapper.Map<MonedaExistentaDto>(moneda));
        }

        // GET: Admin/Moneda/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Admin/Moneda/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([FromForm]MonedaNouaDto monedaNoua)
        {
            if (ModelState.IsValid)
            {
                var moneda = _mapper.Map<Moneda>(monedaNoua);
                _context.Add(moneda);
                await _context.SaveChangesAsync();
                TempData["MesajMoneda"] = $"Am adăugat moneda {monedaNoua.Denumire} ({monedaNoua.Acronim})!";
                return RedirectToAction(nameof(Index));
            }
            return View(monedaNoua);
        }

        // GET: Admin/Moneda/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Monezi == null)
            {
                return NotFound();
            }

            var monedaExistenta = await _context.Monezi.FindAsync(id);
            if (monedaExistenta == null)
            {
                return NotFound();
            }
            return View(_mapper.Map<MonedaExistentaDto>(monedaExistenta));
        }

        // POST: Admin/Moneda/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [FromForm]MonedaExistentaDto monedaModificata)
        {
            if (id != monedaModificata.Id)
            {
                return NotFound();
            }
            var monedaExistenta = await _context.Monezi.FindAsync(id);
            if (monedaExistenta == null)
            {
                return NotFound();
            }
            if (id != monedaExistenta.Id)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    TempData["MesajMoneda"] = $"Moneda <strong>{monedaExistenta.Denumire} ({monedaExistenta.Acronim})</strong> a fost redenumită <strong>{monedaModificata.Denumire} ({monedaModificata.Acronim})</strong>!";
                    monedaExistenta.Denumire = monedaModificata.Denumire;
                    monedaExistenta.Acronim= monedaModificata.Acronim;
                    _context.Update(monedaExistenta);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MonedaExists(monedaExistenta.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(monedaModificata);
        }

        // GET: Admin/Moneda/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Monezi == null)
            {
                return NotFound();
            }

            var monedaExistenta = _mapper.Map<MonedaExistentaDto>(await _context.Monezi.FirstOrDefaultAsync(m => m.Id == id));
            if (monedaExistenta == null)
            {
                return NotFound();
            }

            return View(monedaExistenta);
        }

        // POST: Admin/Moneda/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Monezi == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Monezi'  is null.");
            }
            var monedaExistenta = await _context.Monezi
                .Include(t=>t.Carti)
                .FirstOrDefaultAsync(i=>i.Id==id);
            if (monedaExistenta == null)
            { 
                return NotFound(); 
            }
            else
            {
                if (monedaExistenta.Carti!.Count() > 0)
                {
                    TempData["MesajMoneda"] = $"Moneda <strong>{monedaExistenta.Denumire}</strong> NU a fost ștearsă pentru că este asociată unor cărți!";
                }
                else
                {
                    _context.Monezi.Remove(monedaExistenta);
                    TempData["MesajMoneda"] = $"Moneda <strong>{monedaExistenta.Denumire}</strong> a fost ștearsă cu succes!";
                }
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MonedaExists(int id)
        {
          return (_context.Monezi?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
