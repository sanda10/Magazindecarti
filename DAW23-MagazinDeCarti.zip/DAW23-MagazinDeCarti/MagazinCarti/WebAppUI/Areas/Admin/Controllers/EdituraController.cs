﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Scaffolding;
using Microsoft.EntityFrameworkCore.ValueGeneration.Internal;
using WebAppUI.Areas.Admin.Models.DTOs;
using WebAppUI.Areas.Admin.Models.ViewModels;
using WebAppUI.Models.CustomIdentity;
namespace WebAppUI.Areas.Admin.Controllers;

[Area("Admin")]
[Authorize(Roles ="Administrator")]
public class EdituraController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly IMapper _mapper;
    private readonly UserManager<AppUser> _userManager;

    public EdituraController(ApplicationDbContext context, IMapper mapper, UserManager<AppUser> userManager)
    {
        _context = context;
        _mapper = mapper;
        _userManager = userManager;
    }

    // GET: Admin/Editura
    public async Task<IActionResult> Index()
    {
        if (_context.Edituri== null)
            return Problem("Entity set 'ApplicationDbContext.Monezi'  is null.");
        return View(_mapper.Map<List<EdituraExistentaDto>>(await _context.Edituri.ToListAsync()));
    }

    // GET: Admin/Editura/Details/5
    public async Task<IActionResult> Details(int? id)
    {
        if (id == null || _context.Edituri == null)
        {
            return NotFound();
        }

        var edituraExistenta = _mapper.Map<EdituraExistentaDto>(await _context.Edituri.FirstOrDefaultAsync(m => m.Id == id));
        if (edituraExistenta == null)
        {
            return NotFound();
        }

        return View(edituraExistenta);
    }

    // GET: Admin/Editura/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST: Admin/Editura/Create
    // To protect from overposting attacks, enable the specific properties you want to bind to.
    // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([FromForm]EdituraNouaDto edituraNoua)
    {
        if (ModelState.IsValid)
        {
            var editura = _mapper.Map<Editura>(edituraNoua);
            _context.Add(editura);
            await _context.SaveChangesAsync();
            TempData["MesajEditura"] = $"Am adăugat editura <strong>{edituraNoua.Denumire}</strong>!";
            return RedirectToAction(nameof(Index));
        }
        return View(edituraNoua);
    }

    // GET: Admin/Editura/Edit/5
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null || _context.Edituri == null)
        {
            return NotFound();
        }

        var edituraExistenta = _mapper.Map<EdituraExistentaDto>(await _context.Edituri.FindAsync(id));
        if (edituraExistenta == null)
        {
            return NotFound();
        }
        return View(edituraExistenta);
    }

    // POST: Admin/Editura/Edit/5
    // To protect from overposting attacks, enable the specific properties you want to bind to.
    // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [FromForm] EdituraExistentaDto edituraModificata)
    {
        if (id != edituraModificata.Id)
        {
            return NotFound();
        }
        var edituraExistenta = await _context.Edituri.FindAsync(id);
        if (edituraExistenta == null)
        {
            return NotFound();
        }
        if (edituraExistenta.Id != edituraModificata.Id)
        {
            return BadRequest();
        }
        if (ModelState.IsValid)
        {
            try
            {
                TempData["MesajEditura"] = $"Am modificat editura <strong>{edituraExistenta.Denumire}</strong> în <strong>{edituraModificata.Denumire}</strong>!";
                edituraExistenta.Denumire = edituraModificata.Denumire;
                _context.Update(edituraExistenta);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EdituraExists(edituraExistenta.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return RedirectToAction(nameof(Index));
        }
        return View(edituraModificata);
    }

    // GET: Admin/Editura/Delete/5
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null || _context.Edituri == null)
        {
            return NotFound();
        }

        var edituraExistenta = _mapper.Map<EdituraExistentaDto>(await _context.Edituri.FirstOrDefaultAsync(m => m.Id == id));
        if (edituraExistenta == null)
        {
            return NotFound();
        }

        return View(edituraExistenta);
    }

    // POST: Admin/Editura/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        if (_context.Edituri == null)
        {
            return Problem("Entity set 'ApplicationDbContext.Edituri'  is null.");
        }
        var edituraExistenta = await _context.Edituri
            .Include(t=>t.Carti)
            .Include(t=>t.Manageri)
            .FirstOrDefaultAsync(i=>i.Id==id);
        if (edituraExistenta == null)
        {
            return NotFound();
        }else
        {
            if (edituraExistenta.Carti!.Count == 0 && edituraExistenta.Manageri!.Count == 0)
            {
                _context.Edituri.Remove(edituraExistenta);
                TempData["MesajEditura"] = $"Editura <strong>{edituraExistenta.Denumire}</strong> a fost ștearsă cu succes!";
            }
            else
            {
                TempData["MesajEditura"] = $"Editura <strong>{edituraExistenta.Denumire}</strong> NU poate fi ștearsă acum deoarece are cărți sau useri asociați!";
            }                
        }            
        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    // GET: Admin/Editura/Edit/5
    public async Task<IActionResult> Managers(int id)
    {
        if (_context.Edituri == null)
        {
            return NotFound();
        }

        var edituraExistenta = await _context.Edituri
            .Include(t=>t.Manageri)
            .FirstOrDefaultAsync(i=>i.Id == id);
        if (edituraExistenta is null)
        {
            return NotFound();
        }
        var manageri = _mapper.Map<List<UtilizatorExistentDto>>(await _userManager.GetUsersInRoleAsync("Manager"));

        var manageriAsociati = await _context.EdituraManageri.Where(c => c.EdituraId == id).ToListAsync();

        for(var i = manageri.Count - 1; i >= 0; i--)
        {
            if (!manageriAsociati.Any(m => m.ManagerId == manageri[i].Id))
            {
                manageri.Remove(manageri[i]);
            }
        }        
        var output = new EdituraManageriVm()
        {
            Id=id,
            Denumire = edituraExistenta.Denumire,
            listaManageri = manageri
        };
        return View(output);
    }

    public async Task<IActionResult> AddManager(int id)
    {
        if (_context.Edituri == null)
        {
            return NotFound();
        }

        var edituraExistenta = await _context.Edituri
            .FirstOrDefaultAsync(i => i.Id == id);
        if (edituraExistenta is null)
        {
            return NotFound();
        }

        var manageri = _mapper.Map<List<UtilizatorExistentDto>>(await _userManager.GetUsersInRoleAsync("Manager"));
        ViewBag.Managers = new SelectList(manageri, "Id", "Email");
        return View(new EdituraManagerDto() { 
            EdituraId = id,
            Editura = edituraExistenta.Denumire
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AddManager([FromRoute] int id, [FromForm] EdituraManagerDto utilizatorEditura)
    {
        if (_context.Edituri == null)
        {
            return NotFound();
        }

        var edituraExistenta = await _context.Edituri
            .Include(t => t.Manageri)
            .FirstOrDefaultAsync(i => i.Id == id);
        if (edituraExistenta is null)
        {
            return NotFound();
        }
        if(ModelState.IsValid)
        {
            var managerExistent = _context.EdituraManageri.Where(q=>q.EdituraId == id && q.ManagerId == utilizatorEditura.ManagerId).FirstOrDefault();
            if(managerExistent is null)
            {
                var managerEditura = new EdituraManager()
                {
                    EdituraId = id,
                    ManagerId = utilizatorEditura.ManagerId
                };
                await _context.EdituraManageri.AddAsync(managerEditura);
                await _context.SaveChangesAsync();
                TempData["MesajEdituraManager"] = $"Managerul a fost asociat!";
            }
            else
            {
                TempData["MesajEdituraManager"] = "Managerul este asociat deja!";
            }
            return RedirectToAction(nameof(AddManager), new { id});
        }
        var manageri = _mapper.Map<List<UtilizatorExistentDto>>(await _userManager.GetUsersInRoleAsync("Manager"));
        ViewBag.Managers = new SelectList(manageri, "Id", "Email", utilizatorEditura.ManagerId);
        return View(utilizatorEditura);
    }


    private bool EdituraExists(int id)
    {
      return (_context.Edituri?.Any(e => e.Id == id)).GetValueOrDefault();
    }
}
