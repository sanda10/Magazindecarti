﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAppUI.Areas.Admin.Models.DTOs;
using WebAppUI.Models.CustomIdentity;
namespace WebAppUI.Areas.Admin.Controllers;
[Area("Admin")]
[Authorize(Roles = "Administrator")]
public class RolController : Controller
{
    public readonly IMapper _mapper;
    public readonly ApplicationDbContext _context;
    public readonly UserManager<AppUser> _userManager;
    public readonly RoleManager<AppRole> _roleManager;

    public RolController(IMapper mapper, ApplicationDbContext context, UserManager<AppUser> userManager, RoleManager<AppRole> roleManager)
    {
        _context = context;
        _mapper = mapper;
        _userManager = userManager;
        _roleManager = roleManager;
    }
    public async Task<IActionResult> Index()
    {
        var roluri = _mapper.Map<List<RolExistent>>(await _roleManager.Roles.ToListAsync());
        return View(roluri);
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([FromForm] RolNouDto rolNou)
    {
        if (ModelState.IsValid)
        {
            if(!await _roleManager.RoleExistsAsync(rolNou.Denumire))
            {
                await _roleManager.CreateAsync(new AppRole() { Name = rolNou.Denumire });
                TempData["MesajRol"] = $"Rolul <strong>{rolNou.Denumire}</strong> a fost adăugat cu succes!";
            }
            else
            {
                TempData["MesajRol"] = $"Rolul <strong>{rolNou.Denumire}</strong> există deja!";
            }
            return RedirectToAction(nameof(Index));
        }
        return View(rolNou);
    }

    public async Task<IActionResult> Edit(int id)
    {
        var rolExistent = _mapper.Map<RolExistent>(await _roleManager.Roles.FirstOrDefaultAsync(i=>i.Id == id));
        if (rolExistent == null)
            return NotFound();
        return View(rolExistent);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id,[FromForm] RolExistent rolModificat)
    {
        var rolExistent = await _roleManager.Roles.FirstOrDefaultAsync(i => i.Id == id);
        if (rolExistent is null)
            return NotFound();
        if (rolExistent.Id != id)
            return BadRequest();        
        if (ModelState.IsValid)
        {
            if (!await _roleManager.RoleExistsAsync(rolModificat.Denumire))
            {
                rolExistent.Name = rolModificat.Denumire;
                await _roleManager.UpdateAsync(rolExistent);
                TempData["MesajRol"] = $"Rolul <strong>{rolModificat.Denumire}</strong> a fost actualizat cu succes!";
            }
            else
            {
                TempData["MesajRol"] = $"Rolul <strong>{rolModificat.Denumire}</strong> există deja!";
            }
            return RedirectToAction(nameof(Index));
        }
        return View(rolModificat);
    }

    public async Task<IActionResult> Delete(int id)
    {
        var rolExistent = _mapper.Map<RolExistent>(await _roleManager.Roles.FirstOrDefaultAsync(i => i.Id == id));
        if (rolExistent == null)
            return NotFound();
        return View(rolExistent);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [ActionName(nameof(Delete))]
    public async Task<IActionResult> ConfirmDelete(int id)
    {
        var rolExistent = await _roleManager.Roles.FirstOrDefaultAsync(i => i.Id == id);
        if (rolExistent == null)
            return NotFound();
        if (ModelState.IsValid)
        {
            var utilizatori = await _userManager.GetUsersInRoleAsync(rolExistent.Name!);
            if (utilizatori.Count>0)
            {
                TempData["MesajRol"] = $"Rolul <strong>{rolExistent.Name}</strong> nu poate fi șters deoarece are {utilizatori.Count} utilizatori!";
            }
            else
            {
                await _roleManager.DeleteAsync(rolExistent);
                TempData["MesajRol"] = $"Rolul <strong>{rolExistent.Name}</strong> a fost șters!";
            }
            return RedirectToAction(nameof(Index));
        }
        return View(_mapper.Map<RolExistent>(rolExistent));
    }
}
