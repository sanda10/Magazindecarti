﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text;
using WebAppUI.Areas.Admin.Models.DTOs;
using WebAppUI.Models.CustomIdentity;
namespace WebAppUI.Areas.Admin.Controllers;
[Area("Admin")]
[Authorize(Roles = "Administrator")]
public class UtilizatorController : Controller
{
    public readonly IMapper _mapper;
    public readonly ApplicationDbContext _context;
    public readonly SignInManager<AppUser> _signInManager;
    public readonly UserManager<AppUser> _userManager;
    public readonly RoleManager<AppRole> _roleManager;

    public UtilizatorController(IMapper mapper, ApplicationDbContext context, UserManager<AppUser> userManager, RoleManager<AppRole> roleManager, SignInManager<AppUser> signInManager)
    {
        _context = context;
        _mapper = mapper;
        _userManager = userManager;
        _roleManager = roleManager;
        _signInManager = signInManager;
    }
    public async Task<IActionResult> Index()
    {
        var utilizatori = _mapper.Map<List<UtilizatorExistentDto>>(await _userManager.Users.ToListAsync());
        foreach(var utilizator in utilizatori)
        {
            var utilizatorCurent = await _userManager.FindByEmailAsync(utilizator.Email);
            utilizator.IsManager = await _userManager.IsInRoleAsync(utilizatorCurent!, "Manager");
            utilizator.IsAdmin = await _userManager.IsInRoleAsync(utilizatorCurent!, "Administrator");
        }
        return View(utilizatori);
    }

    public async Task<IActionResult> Edit(int id)
    {
        var utilizatorExistent = await _userManager.Users.FirstOrDefaultAsync(i=>i.Id == id);
        if(utilizatorExistent is null)
            return NotFound();
        var output = _mapper.Map<UtilizatorExistentDto>(utilizatorExistent);
        output.IsAdmin = await _userManager.IsInRoleAsync(utilizatorExistent, "Administrator");
        output.IsManager = await _userManager.IsInRoleAsync(utilizatorExistent, "Manager");
        return View(output);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [FromForm]UtilizatorExistentDto utilizatorModificat)
    {
        var utilizatorExistent = await _userManager.Users.FirstOrDefaultAsync(i => i.Id == id);
        if (utilizatorExistent is null)
            return NotFound();
        if (id != utilizatorModificat.Id || !utilizatorModificat.Email.Equals(utilizatorExistent.Email))
            return BadRequest();
        if (ModelState.IsValid)
        {
            if (!await _roleManager.RoleExistsAsync("Manager"))
                await _roleManager.CreateAsync(new() { Name="Manager" });
            StringBuilder mesaj = new();
            if (utilizatorModificat.IsManager)
            {
                if(!await _userManager.IsInRoleAsync(utilizatorExistent, "Manager"))
                {
                    await _userManager.AddToRoleAsync(utilizatorExistent, "Manager");
                    mesaj.Append($"Utilizatorul <strong>{utilizatorExistent.Email}</strong> a devenit <strong>Manager</strong>!<br/>");
                    //TempData["MesajUtilizator"] = $"Utilizatorul <strong>{utilizatorExistent.Email}</strong> a devenit <strong>Manager</strong>!";
                }
                else
                {
                    mesaj.Append($"Utilizatorul <strong>{utilizatorExistent.Email}</strong> a rămas <strong>Manager</strong>!<br/>");
                    //TempData["MesajUtilizator"] = $"Utilizatorul <strong>{utilizatorExistent.Email}</strong> a rămas <strong>Manager</strong>!";
                }
            }
            else
            {
                if (await _userManager.IsInRoleAsync(utilizatorExistent, "Manager"))
                {
                    await _userManager.RemoveFromRolesAsync(utilizatorExistent, new string[] { "Manager" });
                    mesaj.Append($"Utilizatorul <strong>{utilizatorExistent.Email}</strong> nu mai este <strong>Manager</strong>!<br/>");
                    //TempData["MesajUtilizator"] = $"Utilizatorul <strong>{utilizatorExistent.Email}</strong> nu mai este <strong>Manager</strong>!";
                }
                else
                {
                    mesaj.Append($"Utilizatorul <strong>{utilizatorExistent.Email}</strong> nu este, în continuare, <strong>Manager</strong>!<br/>");
                    //TempData["MesajUtilizator"] = $"Utilizatorul <strong>{utilizatorExistent.Email}</strong> nu este, în continuare, <strong>Manager</strong>!";
                }
            }
            if (utilizatorModificat.IsAdmin)
            {
                if (!await _userManager.IsInRoleAsync(utilizatorExistent, "Administrator"))
                {
                    await _userManager.AddToRoleAsync(utilizatorExistent, "Administrator");
                    mesaj.Append($"Utilizatorul <strong>{utilizatorExistent.Email}</strong> a devenit <strong>Administrator</strong>!<br/>");
                    //TempData["MesajUtilizator"] = $"Utilizatorul <strong>{utilizatorExistent.Email}</strong> a devenit <strong>Administrator</strong>!";
                }
                else
                {
                    mesaj.Append($"Utilizatorul <strong>{utilizatorExistent.Email}</strong> a rămas <strong>Administrator</strong>!");
                    //TempData["MesajUtilizator"] = $"Utilizatorul <strong>{utilizatorExistent.Email}</strong> a rămas <strong>Administrator</strong>!";
                }
            }
            else
            {
                if (await _userManager.IsInRoleAsync(utilizatorExistent, "Administrator"))
                {
                    await _userManager.RemoveFromRolesAsync(utilizatorExistent, new string[] { "Administrator" });
                    mesaj.Append($"Utilizatorul <strong>{utilizatorExistent.Email}</strong> nu mai este <strong>Administrator</strong>!<br/>");
                    //TempData["MesajUtilizator"] = $"Utilizatorul <strong>{utilizatorExistent.Email}</strong> nu mai este <strong>Administrator</strong>!";
                }
                else
                {
                    mesaj.Append($"Utilizatorul <strong>{utilizatorExistent.Email}</strong> nu este, în continuare, <strong>Administrator</strong>!");
                    //TempData["MesajUtilizator"] = $"Utilizatorul <strong>{utilizatorExistent.Email}</strong> nu este, în continuare, <strong>Administrator</strong>!";
                }
            }
            TempData["MesajUtilizator"]=mesaj.ToString();

            var currentUser = _userManager.Users.FirstOrDefault(u=>u.Email==User.Identity!.Name);
            if (currentUser!.Id == utilizatorExistent.Id)
            {
                // refresh (al rolurilor) pentru utilizatorul curent
                await _signInManager.RefreshSignInAsync(currentUser!);
            }
            return RedirectToAction(nameof(Index));
        }
        return View(utilizatorModificat);
    }
}
