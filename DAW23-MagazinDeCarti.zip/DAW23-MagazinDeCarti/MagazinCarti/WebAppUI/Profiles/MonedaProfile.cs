﻿using WebAppUI.Areas.Admin.Models.DTOs;
using WebAppUI.Models.CustomIdentity;
namespace WebAppUI.Profiles;
public class MonedaProfile: Profile
{
    public MonedaProfile()
    {
        CreateMap<MonedaNouaDto, Moneda>();
        CreateMap<Moneda, MonedaExistentaDto>();
    }
}
