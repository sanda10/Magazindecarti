﻿using WebAppUI.Areas.Manager.Models.DTOs;
using WebAppUI.Areas.Manager.Models.ViewModels;
using WebAppUI.Models.ViewModels;
namespace WebAppUI.Profiles;
public class AutorProfile: Profile
{
    public AutorProfile()
    {
        //CreateMap<AutorNouDto, Autor>();

        CreateMap<AutorNouDto,Autor>()
            .ForMember(d=>d.Nume, s=>s.MapFrom(src=>src.Nume))
            .ForMember(d => d.Prenume, s => s.MapFrom(src => src.Prenume))
            .ForMember(d => d.DataNastere, s => s.MapFrom(src => src.DataNastere));

        CreateMap<Autor, AutorExistentDto>()
            .ForMember(d => d.AutorId, s => s.MapFrom(src => src.Id));

        CreateMap<Autor, AutorScurtVm>()
            .ForMember(d => d.AutorId, s => s.MapFrom(src => src.Id))
            .ForMember(d => d.NumeComplet, s => s.MapFrom(src => $"{src.Prenume} {src.Nume} ({src.DataNastere.Year})"));

        CreateMap<CarteAutor, AutorScurtVm>()
            .ForMember(d => d.AutorId, s => s.MapFrom(src => src.Autor!.Id))
            .ForMember(d => d.NumeComplet, s => s.MapFrom(src => $"{src.Autor!.Prenume} {src.Autor!.Nume} ({src.Autor!.DataNastere.Year})"));

        CreateMap<Autor, AutorDetaliiVm>()
            .ForMember(d => d.NumeComplet, s => s.MapFrom(src => $"{src.Prenume} {src.Nume}"));

        CreateMap<Autor, AutorAdaugaCarteDto>()
            .ForMember(d => d.AutorId, s => s.MapFrom(src => src.Id))
            .ForMember(d => d.Autor, s => s.MapFrom(src => $"{src.Prenume} {src.Nume} ({src.DataNastere.Year})"));
        
        CreateMap<Autor, CardAutorVm>()
            .ForMember(d => d.AutorId, s => s.MapFrom(src => src.Id));
    }
}
