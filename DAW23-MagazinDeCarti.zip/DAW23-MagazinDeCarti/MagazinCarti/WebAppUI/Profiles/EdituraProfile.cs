﻿using WebAppUI.Areas.Admin.Models.DTOs;
namespace WebAppUI.Profiles;

public class EdituraProfile : Profile
{
    public EdituraProfile()
    {
        CreateMap<EdituraNouaDto, Editura>();
        CreateMap<Editura, EdituraExistentaDto>();
    }
}
