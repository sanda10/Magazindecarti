﻿using WebAppUI.Areas.Manager.Models.DTOs;
using WebAppUI.Areas.Manager.Models.ViewModels;
using WebAppUI.Models.ViewModels;
namespace WebAppUI.Profiles;

public class CarteProfile : Profile
{
    public CarteProfile()
    {
        CreateMap<Carte, CarteVm>()
            .ForMember(d => d.Moneda, s => s.MapFrom(src => src.Moneda!.Acronim));

        CreateMap<CarteNouaDto, Carte>()
            .ForMember(d => d.EsteFinala, s => s.MapFrom(src => false));

        CreateMap<Carte, CarteExistentaDto>();

        CreateMap<Carte, CarteDto>()
            .ForMember(d => d.CarteId, s => s.MapFrom(src => src.Id))
            .ForMember(d => d.Titlu, s => s.MapFrom(src => $"{src.Titlu} ({src.ISBN})"));

        CreateMap<Carte, CarteDetaliiVm>();

        CreateMap<CarteOferta, OfertaCarteVm>()
            .ForMember(d => d.Id, s => s.MapFrom(src => src.Id))
            .ForMember(d => d.Titlu, s => s.MapFrom(src => src.Carte!.Titlu))
            .ForMember(d => d.Pret, s => s.MapFrom(src => src.Carte!.Pret))
            .ForMember(d => d.PretNou, s => s.MapFrom(src => src.PretNou))
            .ForMember(d => d.Moneda, s => s.MapFrom(src => src.Carte!.Moneda!.Acronim));

        CreateMap<Carte, OfertaCarteDto>()
            .ForMember(d => d.Id, s => s.MapFrom(src => src.Id))
            .ForMember(d => d.Titlu, s => s.MapFrom(src => src.Titlu))
            .ForMember(d => d.Pret, s => s.MapFrom(src => src.Pret))
            .ForMember(d => d.Moneda, s => s.MapFrom(src => src.Moneda!.Acronim));

        CreateMap<OfertaCarteDto, CarteOferta>();

        CreateMap<AddEditOfertaCarteDto, CarteOferta>();

        CreateMap<Carte, CartePretVm>()
            .ForMember(d => d.Moneda, s => s.MapFrom(src => src.Moneda!.Acronim));

        CreateMap<Carte, CardCarteVm>()
            .ForMember(d => d.PretNou, s => s.MapFrom(src => src.Oferta != null ? src.Oferta.PretNou : 0))
            .ForMember(d => d.Editura, s => s.MapFrom(src => src.Editura!.Denumire))
            .ForMember(d => d.Moneda, s => s.MapFrom(src => src.Moneda!.Acronim))
            .ForMember(d => d.Autori, s => s.MapFrom(src => string.Join(", ", src.Autori!.Select(a => $"{a.Autor!.Prenume} {a.Autor!.Nume}"))));

        CreateMap<Carte, CarteDetailsVm>()
            .ForMember(d => d.PretNou, s => s.MapFrom(src => src.Oferta != null ? src.Oferta.PretNou : 0))
            .ForMember(d => d.Editura, s => s.MapFrom(src => src.Editura!.Denumire))
            .ForMember(d => d.Moneda, s => s.MapFrom(src => src.Moneda!.Acronim))
            .ForMember(d => d.Autori, s => s.MapFrom(src => string.Join(", ", src.Autori!.Select(a => $"{a.Autor!.Prenume} {a.Autor!.Nume}"))));
    }
}
