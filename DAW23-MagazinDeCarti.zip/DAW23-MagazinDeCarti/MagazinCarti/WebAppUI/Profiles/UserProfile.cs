﻿using WebAppUI.Areas.Admin.Models.DTOs;
using WebAppUI.Models.CustomIdentity;
namespace WebAppUI.Profiles;
public class UserProfile: Profile
{
    public UserProfile()
    {
        CreateMap<AppUser, UtilizatorExistentDto>()
            .ForMember(d => d.Id, s => s.MapFrom(src => src.Id))
            .ForMember(d => d.Email, s => s.MapFrom(src => src.UserName));

    }
}
