﻿using WebAppUI.Areas.Admin.Models.DTOs;
using WebAppUI.Areas.Manager.Models.DTOs;
using WebAppUI.Areas.Manager.Models.ViewModels;
using WebAppUI.Models.CustomIdentity;

namespace WebAppUI.Profiles
{
    public class RoleProfile: Profile
    {
        public RoleProfile()
        {
            CreateMap<AppRole,RolNouDto>()
                .ForMember(d=>d.Denumire, s=>s.MapFrom(src=>src.Name));

            CreateMap<AppRole, RolExistent>()
                .ForMember(d => d.Id, s => s.MapFrom(src => src.Id))
                .ForMember(d => d.Denumire, s => s.MapFrom(src => src.Name));

        }
    }
}
