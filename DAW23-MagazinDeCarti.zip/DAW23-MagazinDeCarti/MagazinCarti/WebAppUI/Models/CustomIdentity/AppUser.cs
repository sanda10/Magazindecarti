﻿using Microsoft.AspNetCore.Identity;

namespace WebAppUI.Models.CustomIdentity
{
    public class AppUser: IdentityUser<int>
    {
        // Legatura cu editurile
        public ICollection<EdituraManager>? Edituri { get; set; }
    }
}
