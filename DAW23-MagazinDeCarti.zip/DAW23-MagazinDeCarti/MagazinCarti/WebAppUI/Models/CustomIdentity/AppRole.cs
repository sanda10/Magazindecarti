﻿using Microsoft.AspNetCore.Identity;

namespace WebAppUI.Models.CustomIdentity
{
    public class AppRole: IdentityRole<int>
    {
    }
}
