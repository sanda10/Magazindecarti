﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WebAppUI.Models.CustomIdentity;

namespace WebAppUI.Models.Entities;
[Table("R_Editura_Manager")]
[PrimaryKey(nameof(ManagerId), nameof(EdituraId))]
public class EdituraManager
{
    [Column("UserId")]
    public int ManagerId { get; set; }
    public int EdituraId { get; set; }
    [ForeignKey(nameof(ManagerId))]
    public AppUser? Manager { get; set; }
    [ForeignKey(nameof(EdituraId))]
    public Editura? Editura { get; set; }
}
