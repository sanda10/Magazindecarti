﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebAppUI.Models.Entities;
[Table("R_Carte_Autor")]
[PrimaryKey(nameof(CarteId), nameof(AutorId))]
public class CarteAutor
{
    public int CarteId { get; set; }
    [ForeignKey(nameof(CarteId))]
    public Carte? Carte { get; set; }
    public int AutorId { get; set; }
    [ForeignKey(nameof (AutorId))]
    public Autor? Autor { get; set; }
}
