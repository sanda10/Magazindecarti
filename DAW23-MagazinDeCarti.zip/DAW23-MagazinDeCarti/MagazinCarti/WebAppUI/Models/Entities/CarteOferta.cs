﻿using System.ComponentModel.DataAnnotations.Schema;
namespace WebAppUI.Models.Entities;
[Table("R_Carte_Oferta")]
public class CarteOferta
{
    [Column("CarteOfertaId")]
    public int Id { get; set; }
    [ForeignKey(nameof(Id))]
    public Carte? Carte { get; set; }
    public string TextPromo { get; set; } = string.Empty;
    public decimal PretNou { get; set; }
}
