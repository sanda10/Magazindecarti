﻿using System.ComponentModel.DataAnnotations.Schema;
namespace WebAppUI.Models.Entities;
[Table("T_Carte")]
public class Carte
{
    [Column("CarteId")]
    public int Id { get; set; }
    public string Titlu { get; set; } = string.Empty;
    public decimal Pret { get; set; }
    public int MonedaId { get; set; }
    [ForeignKey(nameof(MonedaId))]
    public Moneda? Moneda { get; set; }
    public int EdituraId { get; set; }
    [ForeignKey(nameof(EdituraId))]
    public Editura? Editura { get; set; }
    public short AnPublicare { get; set; }
    public string ISBN { get; set; } = string.Empty;
    public bool EsteFinala { get; set; } = false;
    public CarteOferta? Oferta { get; set; }
    public ICollection<CarteAutor>? Autori { get; set; }
}
