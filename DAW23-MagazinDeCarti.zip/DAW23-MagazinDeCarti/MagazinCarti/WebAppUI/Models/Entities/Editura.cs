﻿using System.ComponentModel.DataAnnotations.Schema;
namespace WebAppUI.Models.Entities;
[Table("N_Editura")]
public class Editura
{
    [Column("EdituraId")]
    public int Id { get; set; }
    public string Denumire { get; set; }=string.Empty;
    public ICollection<Carte>? Carti { get; set; }
    public ICollection<EdituraManager>? Manageri { get; set; }
}
