﻿using System.ComponentModel.DataAnnotations.Schema;

namespace WebAppUI.Models.Entities
{
    [Table("N_Autor")]
    public class Autor
    {
        [Column("AutorId")]
        public int Id { get; set; }
        public string Prenume { get; set; } = string.Empty;
        public string Nume { get; set; } = string.Empty;
        public DateTime DataNastere { get; set; }
        public ICollection<CarteAutor>? Carti { get; set; }
    }
}
