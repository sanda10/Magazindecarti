﻿using System.ComponentModel.DataAnnotations.Schema;
namespace WebAppUI.Models.Entities;
[Table("N_Moneda")]
public class Moneda
{
    [Column("MonedaId")]
    public int Id { get; set; }
    public string Denumire { get; set; } = string.Empty;
    public string Acronim { get; set; } = string.Empty;
    public ICollection<Carte>? Carti { get; set; }
}
