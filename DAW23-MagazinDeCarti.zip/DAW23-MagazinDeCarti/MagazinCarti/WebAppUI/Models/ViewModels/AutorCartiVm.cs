namespace WebAppUI.Models.ViewModels;
public class AutorCartiVm
{
    public CardAutorVm? AutorDetalii { get; set; }
    public List<CardCarteVm>? Carti { get; set; }
}