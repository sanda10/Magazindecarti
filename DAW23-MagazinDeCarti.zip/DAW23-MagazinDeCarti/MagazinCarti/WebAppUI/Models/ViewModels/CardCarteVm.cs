namespace WebAppUI.Models.ViewModels;
public class CardCarteVm
{
    public int Id { get; set; }
    public string Titlu { get; set; }=string.Empty;
    public string ISBN { get; set; }=string.Empty;
    public string Editura { get; set; }=string.Empty;
    public string Autori { get; set; }=string.Empty;
    public short AnPublicare { get; set; }
    public decimal Pret { get; set; }
    public decimal PretNou { get; set; }
    public string Moneda { get; set; }=string.Empty;
    // public CardCarteVm()
    // {
    // }
    // public CardCarteVm(Carte Carte)
    // {
    //     if(Carte is not null)
    //     {
    //         Id=Carte.Id;
    //         Titlu=Carte.Titlu;
    //         ISBN=Carte.ISBN;
    //         AnPublicare=Carte.AnPublicare;
    //         Pret=Carte.Pret;
    //         PretNou=Carte.Oferta?.PretNou??0;
    //         Moneda=Carte.Moneda!.Acronim;
    //         Autori=string.Join(", ",Carte.Autori!.Select(a=>$"{a.Autor!.Prenume} {a.Autor!.Nume}"));
    //     }
    // }
}
