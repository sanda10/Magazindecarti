﻿using System.ComponentModel.DataAnnotations;

namespace WebAppUI.Models.ViewModels;
public class CardAutorVm
{
    [Key]
    public int AutorId { get; set; }
    public string Nume { get; set; } = string.Empty;
    public string Prenume { get; set; } = string.Empty;
    [DisplayFormat(DataFormatString ="{0:yyyy}")]
    public DateTime DataNastere { get; set; }
    // public CardAutorVm(Autor autor)
    // {
    //     AutorId = autor.Id;
    //     Nume = autor.Nume;
    //     Prenume = autor.Prenume;
    //     DataNastere = autor.DataNastere;
    // }
}
