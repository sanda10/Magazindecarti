namespace WebAppUI.Models.ViewModels;
public class CarteDetailsVm
{
    public int Id { get; set; }
    public string Titlu { get; set; } = string.Empty;
    public string ISBN { get; set; } = string.Empty;
    public int EdituraId { get; set; }
    public string Editura { get; set; } = string.Empty;
    public List<CardAutorVm>? ListaAutori { get; set; }
    public string Autori { get; set; } = string.Empty;
    public short AnPublicare { get; set; }
    public decimal Pret { get; set; }
    public decimal PretNou { get; set; }
    public string Moneda { get; set; } = string.Empty;
    public string TextPromo { get; set; } = string.Empty;
}