﻿global using WebAppUI.Models.Entities;
global using WebAppUI.Data;
global using AutoMapper;