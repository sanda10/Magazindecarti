﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAppUI.Models.ViewModels;
namespace WebAppUI.Controllers;
public class AutorController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly IMapper _mapper;
    public AutorController(ApplicationDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    [Route("Autori")]
    public async Task<IActionResult> Index()
    {
        var autori = await _context.Autori
            .OrderBy(i=>i.Nume)
            .ThenBy(i=>i.Prenume)
            .ToListAsync();
        return View(_mapper.Map<List<CardAutorVm>>(autori));
    }

    [Route("Autor/Details/{id}")]
    public async Task<IActionResult> Details(int id)
    {
        var Autor = await _context.Autori
            .FirstOrDefaultAsync(i=>i.Id==id);
        if (Autor == null)
            return NotFound();
        var Carti = await _context.Carti
            .Include(t=>t.Editura)
            .Include(t=>t.Moneda)
            .Include(t=>t.Oferta)
            .Where(i => i.Autori!.Any(i => i.AutorId == id) && i.EsteFinala)
            .OrderBy(i => i.Titlu)
            .ToListAsync();
        var output = new AutorCartiVm()
        {
            AutorDetalii = _mapper.Map<CardAutorVm>(Autor),
            Carti = _mapper.Map<List<CardCarteVm>>(Carti)
        };
        return View(output);
    }
}
