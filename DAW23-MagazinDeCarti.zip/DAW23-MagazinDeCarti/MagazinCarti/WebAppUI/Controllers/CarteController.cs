﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAppUI.Models.ViewModels;
namespace WebAppUI.Controllers;
public class CarteController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly IMapper _mapper;
    public CarteController(ApplicationDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    [Route("Carti")]
    public async Task<IActionResult> Index()
    {
        var Carti = await _context.Carti
            .Include(t=>t.Autori!)
                .ThenInclude(t=>t.Autor)
            .Include(t=>t.Editura)
            .Include(t=>t.Moneda)
            .Include(t=>t.Oferta)
            .Where(i => i.EsteFinala)
            .OrderBy(i => i.Titlu)
            .ToListAsync();
        return View(_mapper.Map<List<CardCarteVm>>(Carti));
    }

    [Route("Carte/Details/{id}")]
    public async Task<IActionResult> Details(int id)
    {
        var Carte = _mapper.Map<CarteDetailsVm>(await _context.Carti
            .Include(t=>t.Editura)
            .Include(t=>t.Moneda)
            .Include(t=>t.Oferta)
            .Where(i => i.EsteFinala)
            .FirstOrDefaultAsync(i=>i.Id==id));
        if(Carte == null)
            return NotFound();
        var Autori = _mapper.Map<List<CardAutorVm>>(await _context.Autori
            .Where(i => i.Carti!.Any(i => i.CarteId == id))
            .ToListAsync());
        Carte.ListaAutori = Autori;
        return View(Carte);
    }

    [Route("Oferte")]
    public async Task<IActionResult> Offers()
    {
        var Carti = await _context.Carti
            .Include(t=>t.Autori!)
                .ThenInclude(t=>t.Autor)
            .Include(t=>t.Editura)
            .Include(t=>t.Moneda)
            .Include(t=>t.Oferta)
            .Where(i => i.EsteFinala && i.Oferta!=null)
            .OrderBy(i => i.Titlu)
            .ToListAsync();
        return View(_mapper.Map<List<CardCarteVm>>(Carti));
    }
}
