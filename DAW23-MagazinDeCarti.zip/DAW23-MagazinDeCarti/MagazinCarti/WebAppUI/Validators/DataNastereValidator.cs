using System.ComponentModel.DataAnnotations;
namespace WebAppUI.Validators;
public class DataNastereAttribute : ValidationAttribute
{
    protected override ValidationResult IsValid(object? value, ValidationContext validationContext)
    {
        if (value is DateTime dataNastere)
        {
            if (dataNastere > DateTime.Now)
            {
                return new ValidationResult("Data nașterii nu poate fi în viitor");
            }
            return ValidationResult.Success!;
        }
        return new ValidationResult("Data nașterii nu este validă");
    }
}