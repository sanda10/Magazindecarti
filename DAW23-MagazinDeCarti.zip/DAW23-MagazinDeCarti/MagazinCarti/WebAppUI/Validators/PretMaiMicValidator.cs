using System.ComponentModel.DataAnnotations;
namespace WebAppUI.Validators;
public class PretMaiMicDecatAttribute : ValidationAttribute
{
    private readonly string _altaProprietate;

    public PretMaiMicDecatAttribute(string altaProprietate)
    {
        _altaProprietate = altaProprietate;
    }

    protected override ValidationResult IsValid(object? value, ValidationContext validationContext)
    {
        var cealaltaProprietate = validationContext.ObjectType.GetProperty(_altaProprietate);

        if (cealaltaProprietate == null)
        {
            throw new ArgumentException($"Proprietatea {_altaProprietate} nu a fost găsită.");
        }

        var otherValue = cealaltaProprietate.GetValue(validationContext.ObjectInstance);

        if (value != null && otherValue != null && (decimal)value >= (decimal)otherValue)
        {
            return new ValidationResult(ErrorMessage ?? $"{validationContext.DisplayName} trebuie să fie mai mic decât {_altaProprietate}.");
        }

        return ValidationResult.Success!;
    }
}
