using System.ComponentModel.DataAnnotations;
namespace WebAppUI.Validators;
public class PretAttribute : ValidationAttribute
{
    protected override ValidationResult IsValid(object? value, ValidationContext validationContext)
    {
        if (value is decimal pret)
        {
            if (pret <= 0m)
            {
                return new ValidationResult("Prețul nu poate fi negativ sau zero!");
            }
            return ValidationResult.Success!;
        }
        return new ValidationResult("Prețul nu este valid!");
    }
}