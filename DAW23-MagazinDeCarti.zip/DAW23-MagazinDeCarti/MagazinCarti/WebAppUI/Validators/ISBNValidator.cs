using System.ComponentModel.DataAnnotations;
namespace WebAppUI.Validators;
public class ISBNAttribute : ValidationAttribute
{
    protected override ValidationResult IsValid(object? value, ValidationContext validationContext)
    {
        var isbn = value as string;

        if (string.IsNullOrEmpty(isbn))
        {
            return new ValidationResult("ISBN-ul nu poate fi gol");
        }

        if (isbn.Length != 10 && isbn.Length != 13)
        {
            return new ValidationResult("ISBN-ul trebuie să aibă 10 sau 13 caractere");
        }
        if (isbn.Length == 10)
        {
            int suma = 0;
            for (int i = 0; i < isbn.Length - 1; i++)
            {
                if (!char.IsDigit(isbn[i]))
                {
                    return new ValidationResult("ISBN-ul poate conține doar cifre și X");
                }
                suma += (isbn[i] - '0') * (i + 1);
            }
            suma %= 11;
            if (suma == 10)
            {
                if (isbn[isbn.Length - 1] == 'X')
                {
                    return ValidationResult.Success!;
                }
            }
            else
            {
                if ((isbn[isbn.Length - 1] - '0') == suma)
                {
                    return ValidationResult.Success!;
                }
            }
        }
        if (isbn.Length == 13)
        {
            int suma = 0;
            for (int i = 0; i < isbn.Length - 1; i++)
            {
                if (!char.IsDigit(isbn[i]))
                {
                    return new ValidationResult("ISBN-ul poate conține doar cifre");
                }
                if (i % 2 == 0)
                {
                    suma += (isbn[i] - '0');
                }
                else
                {
                    suma += 3 * (isbn[i] - '0');
                }
            }
            suma %= 10;
            if (suma == 0)
            {
                if ((isbn[isbn.Length - 1] - '0') == 0)
                {
                    return ValidationResult.Success!;
                }
            }
            else
            {
                if ((isbn[isbn.Length - 1] - '0') == 10 - suma)
                {
                    return ValidationResult.Success!;
                }
            }
        }
        return new ValidationResult("ISBN-ul nu este valid");
    }
}
